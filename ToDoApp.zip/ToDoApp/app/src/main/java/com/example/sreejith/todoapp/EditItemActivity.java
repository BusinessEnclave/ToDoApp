package com.example.sreejith.todoapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import android.content.Intent;

public class EditItemActivity extends AppCompatActivity {
    EditText etEditSavedText;
    ArrayAdapter<String> aToDoAdapter;
    int pos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);
        etEditSavedText = (EditText) findViewById(R.id.etEditSavedText);
        String ItemTxt = getIntent().getStringExtra("ItemTxt");
        pos = getIntent().getIntExtra("ItemPos",0);
        etEditSavedText.setText(ItemTxt);
    }

    public void onUpdateItem(View view) {
      //  Toast.makeText(getApplicationContext(),"Hello",Toast.LENGTH_SHORT);

        // Prepare data intent
        Intent data = new Intent();
        // Pass relevant data back as a result
        data.putExtra("ItemTxt", etEditSavedText.getText().toString());
        data.putExtra("ItemPos", pos);
        data.putExtra("code", 200); // ints work too
        // Activity finished ok, return the data
        setResult(RESULT_OK, data); // set result code and bundle data for response
        finish(); // closes the activity, pass data to parent
    }



}
